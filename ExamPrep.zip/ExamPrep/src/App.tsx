import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Classes from './pages/Classes';
import Subjects from './pages/Subjects';
import Topics from './pages/Topics';
import Quizzes from './pages/Quizzes';
import Quiz from './pages/Quiz';
import PYQs from './pages/PYQs';
import Notes from './pages/Notes';
import SearchResults from './pages/SearchResults';
import Profile from './pages/Profile';
import AdminRoute from './components/AdminRoute';
import AdminDashboard from './pages/AdminDashboard';
import AdminClasses from './pages/AdminClasses';
import AdminSubjects from './pages/AdminSubjects';
import AdminTopics from './pages/AdminTopics';
import AdminQuizzes from './pages/AdminQuizzes';
import AdminQuestions from './pages/AdminQuestions';
import AdminPYQs from './pages/AdminPYQs';
import AdminNotes from './pages/AdminNotes';
import AdminUsers from './pages/AdminUsers';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/classes" element={<Classes />} />
        <Route path="/subjects/:classId" element={<Subjects />} />
        <Route path="/topics/:subjectId" element={<Topics />} />
        <Route path="/quizzes/:topicId" element={<Quizzes />} />
        <Route path="/quiz/:quizId" element={<Quiz />} />
        <Route path="/pyqs" element={<PYQs />} />
        <Route path="/notes" element={<Notes />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/profile" element={<Profile />} />

        <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
        <Route path="/admin/classes" element={<AdminRoute><AdminClasses /></AdminRoute>} />
        <Route path="/admin/subjects" element={<AdminRoute><AdminSubjects /></AdminRoute>} />
        <Route path="/admin/topics" element={<AdminRoute><AdminTopics /></AdminRoute>} />
        <Route path="/admin/quizzes" element={<AdminRoute><AdminQuizzes /></AdminRoute>} />
        <Route path="/admin/questions/:quizId" element={<AdminRoute><AdminQuestions /></AdminRoute>} />
        <Route path="/admin/pyqs" element={<AdminRoute><AdminPYQs /></AdminRoute>} />
        <Route path="/admin/notes" element={<AdminRoute><AdminNotes /></AdminRoute>} />
        <Route path="/admin/users" element={<AdminRoute><AdminUsers /></AdminRoute>} />
      </Route>
    </Routes>
  );
}
