import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { SearchResult } from '../types';
import { Loader2, Search, HelpCircle, FileText, StickyNote, Layers } from 'lucide-react';

export default function SearchResults() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const search = async () => {
      if (!query) {
        setLoading(false);
        return;
      }

      const [quizzesRes, pyqsRes, notesRes, topicsRes] = await Promise.all([
        supabase.from('quizzes').select('*, topics(name, subjects(name))').ilike('title', `%${query}%`),
        supabase.from('pyqs').select('*, subjects(name, classes(name))').ilike('title', `%${query}%`),
        supabase.from('notes').select('*, topics(name, subjects(name))').ilike('title', `%${query}%`),
        supabase.from('topics').select('*, subjects(name, classes(name))').ilike('name', `%${query}%`),
      ]);

      const combined: SearchResult[] = [
        ...(quizzesRes.data || []).map((q: any) => ({ type: 'quiz' as const, data: q })),
        ...(pyqsRes.data || []).map((p: any) => ({ type: 'pyq' as const, data: p })),
        ...(notesRes.data || []).map((n: any) => ({ type: 'note' as const, data: n })),
        ...(topicsRes.data || []).map((t: any) => ({ type: 'topic' as const, data: t })),
      ];

      setResults(combined);
      setLoading(false);
    };
    search();
  }, [query]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center">
          <Search size={20} className="text-primary-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Search Results</h1>
          <p className="text-sm text-surface-500">{results.length} results for "{query}"</p>
        </div>
      </div>

      {results.length === 0 ? (
        <div className="text-center py-20">
          <Search size={48} className="text-surface-300 mx-auto mb-4" />
          <p className="text-surface-500">No results found for "{query}"</p>
        </div>
      ) : (
        <div className="space-y-3">
          {results.map((result, i) => {
            if (result.type === 'quiz') {
              return (
                <Link
                  key={i}
                  to={`/quiz/${result.data.id}`}
                  className="flex items-center gap-4 bg-white rounded-xl border border-surface-200 p-4 hover:shadow-md transition-all"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary-50 flex items-center justify-center">
                    <HelpCircle size={20} className="text-primary-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-surface-900 truncate">{result.data.title}</h3>
                    <p className="text-xs text-surface-500">Quiz • {result.data.topic_name} • {result.data.subject_name}</p>
                  </div>
                </Link>
              );
            }
            if (result.type === 'pyq') {
              return (
                <div
                  key={i}
                  className="flex items-center gap-4 bg-white rounded-xl border border-surface-200 p-4"
                >
                  <div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center">
                    <FileText size={20} className="text-red-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-surface-900 truncate">{result.data.title}</h3>
                    <p className="text-xs text-surface-500">PYQ • {result.data.year} • {result.data.subject_name}</p>
                  </div>
                </div>
              );
            }
            if (result.type === 'note') {
              return (
                <div
                  key={i}
                  className="flex items-center gap-4 bg-white rounded-xl border border-surface-200 p-4"
                >
                  <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
                    <StickyNote size={20} className="text-amber-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-surface-900 truncate">{result.data.title}</h3>
                    <p className="text-xs text-surface-500">Note • {result.data.topic_name} • {result.data.subject_name}</p>
                  </div>
                </div>
              );
            }
            return (
              <Link
                key={i}
                to={`/quizzes/${result.data.id}`}
                className="flex items-center gap-4 bg-white rounded-xl border border-surface-200 p-4 hover:shadow-md transition-all"
              >
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                  <Layers size={20} className="text-emerald-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-surface-900 truncate">{result.data.name}</h3>
                  <p className="text-xs text-surface-500">Topic • {result.data.subject_name} • {result.data.class_name}</p>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
