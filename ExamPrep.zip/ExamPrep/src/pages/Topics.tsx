import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Topic, Subject, Class } from '../types';
import TopicCard from '../components/TopicCard';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, Layers } from 'lucide-react';

export default function Topics() {
  const { subjectId } = useParams<{ subjectId: string }>();
  const [topics, setTopics] = useState<Topic[]>([]);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [cls, setCls] = useState<Class | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!subjectId) return;
      const { data: subjectData } = await supabase
        .from('subjects')
        .select('*, classes(*)')
        .eq('id', subjectId)
        .single();

      if (subjectData) {
        setSubject(subjectData as Subject);
        setCls((subjectData as any).classes as Class);
      }

      const { data: topicsData } = await supabase
        .from('topics')
        .select('*')
        .eq('subject_id', subjectId)
        .order('name');

      setTopics(topicsData as Topic[] || []);
      setLoading(false);
    };
    fetchData();
  }, [subjectId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <Breadcrumb items={[
        { label: 'Classes', path: '/classes' },
        { label: cls?.name || '', path: `/subjects/${cls?.id}` },
        { label: subject?.name || 'Topics' },
      ]} />
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
          <Layers size={20} className="text-emerald-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">{subject?.name} Topics</h1>
          <p className="text-sm text-surface-500">Select a topic to start quizzes</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {topics.map((topic) => (
          <TopicCard key={topic.id} topic={topic} />
        ))}
      </div>
    </div>
  );
}
