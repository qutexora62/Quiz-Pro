import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Quiz, Question } from '../types';
import { useAuth } from '../context/AuthContext';
import QuestionCard from '../components/QuestionCard';
import Timer from '../components/Timer';
import ResultScreen from '../components/ResultScreen';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, Clock, Play, AlertCircle } from 'lucide-react';

export default function QuizPage() {
  const { quizId } = useParams<{ quizId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [started, setStarted] = useState(false);
  const [timedMode, setTimedMode] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [timeUp, setTimeUp] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!quizId) return;
      const [{ data: quizData }, { data: questionsData }] = await Promise.all([
        supabase.from('quizzes').select('*').eq('id', quizId).single(),
        supabase.from('questions').select('*').eq('quiz_id', quizId).order('id'),
      ]);
      setQuiz(quizData as Quiz);
      setQuestions(questionsData as Question[] || []);
      setLoading(false);
    };
    fetchData();
  }, [quizId]);

  const handleSelect = (questionId: string, option: string) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [questionId]: option }));
  };

  const handleSubmit = useCallback(async () => {
    if (submitted) return;
    setSubmitted(true);

    const score = questions.filter((q) => answers[q.id] === q.correct_option).length;

    if (user) {
      await supabase.from('quiz_attempts').insert({
        user_id: user.id,
        quiz_id: quizId,
        score,
        total_questions: questions.length,
        answers,
      });
    }
  }, [submitted, questions, answers, user, quizId]);

  const handleTimeUp = useCallback(() => {
    setTimeUp(true);
    handleSubmit();
  }, [handleSubmit]);

  const handleRetry = () => {
    setStarted(false);
    setSubmitted(false);
    setAnswers({});
    setTimeUp(false);
    setTimedMode(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  if (!quiz) return <div className="text-center py-20 text-surface-500">Quiz not found</div>;

  if (!started) {
    return (
      <div className="max-w-2xl mx-auto">
        <Breadcrumb items={[
          { label: 'Classes', path: '/classes' },
          { label: 'Quizzes' },
        ]} />
        <div className="bg-white rounded-3xl border border-surface-200 p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary-50 flex items-center justify-center mx-auto mb-4">
            <Play size={32} className="text-primary-600" />
          </div>
          <h1 className="text-2xl font-bold text-surface-900 mb-2">{quiz.title}</h1>
          {quiz.description && <p className="text-surface-500 mb-6">{quiz.description}</p>}

          <div className="flex items-center justify-center gap-6 mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-surface-900">{questions.length}</div>
              <div className="text-xs text-surface-500">Questions</div>
            </div>
            {quiz.time_limit_minutes && (
              <div className="text-center">
                <div className="text-2xl font-bold text-surface-900">{quiz.time_limit_minutes}</div>
                <div className="text-xs text-surface-500">Minutes</div>
              </div>
            )}
          </div>

          {quiz.time_limit_minutes && (
            <div className="flex items-center justify-center gap-3 mb-8 p-4 bg-surface-50 rounded-xl">
              <Clock size={18} className="text-surface-400" />
              <span className="text-sm text-surface-600">Timed Mode</span>
              <button
                onClick={() => setTimedMode(!timedMode)}
                className={`relative w-12 h-6 rounded-full transition-colors ${timedMode ? 'bg-primary-500' : 'bg-surface-300'}`}
              >
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${timedMode ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
          )}

          <button
            onClick={() => setStarted(true)}
            className="w-full max-w-xs bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 rounded-xl transition-colors"
          >
            Start Quiz
          </button>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <ResultScreen
        score={questions.filter((q) => answers[q.id] === q.correct_option).length}
        total={questions.length}
        questions={questions}
        answers={answers}
        onRetry={handleRetry}
      />
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      {timedMode && quiz.time_limit_minutes && (
        <div className="sticky top-20 z-20 flex justify-center mb-4">
          <Timer
            minutes={quiz.time_limit_minutes}
            onTimeUp={handleTimeUp}
            isRunning={started && !submitted}
          />
        </div>
      )}

      {timeUp && (
        <div className="bg-red-50 text-red-700 p-4 rounded-xl mb-4 flex items-center gap-2">
          <AlertCircle size={18} />
          Time's up! Your quiz has been auto-submitted.
        </div>
      )}

      <div className="mb-4 flex items-center justify-between">
        <span className="text-sm text-surface-500">
          {Object.keys(answers).length} of {questions.length} answered
        </span>
        <div className="w-32 h-2 bg-surface-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary-500 rounded-full transition-all"
            style={{ width: `${(Object.keys(answers).length / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {questions.map((q, i) => (
        <QuestionCard
          key={q.id}
          question={q}
          index={i}
          selectedAnswer={answers[q.id] || null}
          onSelect={(opt) => handleSelect(q.id, opt)}
        />
      ))}

      <div className="sticky bottom-24 lg:bottom-6 z-20 flex justify-center">
        <button
          onClick={handleSubmit}
          className="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-8 py-3 rounded-xl shadow-lg shadow-primary-500/25 transition-all hover:scale-105"
        >
          Submit Quiz
        </button>
      </div>
    </div>
  );
}
