import { Link } from 'react-router-dom';
import { BookOpen, FileText, StickyNote, ArrowRight, Zap, Target, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="bg-white rounded-3xl border border-surface-200 p-8 lg:p-12">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary-50 text-primary-700 text-xs font-semibold rounded-full mb-4">
            <Zap size={12} />
            Exam Preparation Platform
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold text-surface-900 mb-4 leading-tight">
            Master Your Exams with{' '}
            <span className="text-primary-600">ExamPrep</span>
          </h1>
          <p className="text-surface-500 text-lg mb-6 leading-relaxed">
            Practice with timed quizzes, access previous year questions, and download handwritten notes — all in one place.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              to="/classes"
              className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors"
            >
              Start Practicing
              <ArrowRight size={18} />
            </Link>
            {!user && (
              <Link
                to="/profile"
                className="inline-flex items-center gap-2 bg-surface-100 hover:bg-surface-200 text-surface-700 font-semibold px-6 py-3 rounded-xl transition-colors"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="grid md:grid-cols-3 gap-4">
        <Link to="/classes" className="group bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg transition-all">
          <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center mb-4 group-hover:bg-primary-500 transition-colors">
            <Target size={24} className="text-primary-600 group-hover:text-white" />
          </div>
          <h3 className="font-bold text-surface-900 mb-2">Timed Quizzes</h3>
          <p className="text-sm text-surface-500">Practice with realistic time limits and get instant feedback on your performance.</p>
        </Link>

        <Link to="/pyqs" className="group bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg transition-all">
          <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center mb-4 group-hover:bg-red-500 transition-colors">
            <FileText size={24} className="text-red-600 group-hover:text-white" />
          </div>
          <h3 className="font-bold text-surface-900 mb-2">Previous Year Questions</h3>
          <p className="text-sm text-surface-500">Download official PYQ papers organized by subject and year.</p>
        </Link>

        <Link to="/notes" className="group bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg transition-all">
          <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center mb-4 group-hover:bg-amber-500 transition-colors">
            <StickyNote size={24} className="text-amber-600 group-hover:text-white" />
          </div>
          <h3 className="font-bold text-surface-900 mb-2">Handwritten Notes</h3>
          <p className="text-sm text-surface-500">Access curated handwritten notes for quick revision before exams.</p>
        </Link>
      </div>

      {/* Stats */}
      <div className="bg-white rounded-2xl border border-surface-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp size={20} className="text-primary-600" />
          <h2 className="font-bold text-surface-900">Why ExamPrep?</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Active Users', value: '10,000+' },
            { label: 'Quizzes', value: '500+' },
            { label: 'PYQs', value: '1,000+' },
            { label: 'Notes', value: '2,000+' },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-3 bg-surface-50 rounded-xl">
              <div className="text-xl font-bold text-primary-600">{stat.value}</div>
              <div className="text-xs text-surface-500">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
