import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { Profile } from '../types';
import { Users, Mail, Calendar } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminUsers() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchUsers(); }, []);

  const fetchUsers = async () => {
    const { data } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    setUsers(data as Profile[] || []);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
          <Users size={20} className="text-blue-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage Users</h1>
          <p className="text-sm text-surface-500">{users.length} registered users</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-surface-200 overflow-hidden">
        {users.map((u) => (
          <div key={u.id} className="flex items-center justify-between p-4 border-b border-surface-100 last:border-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                <span className="text-primary-700 font-bold text-sm">{(u.full_name || u.email)[0].toUpperCase()}</span>
              </div>
              <div>
                <h3 className="font-semibold text-surface-900">{u.full_name || 'Unnamed User'}</h3>
                <div className="flex items-center gap-3 text-xs text-surface-500">
                  <span className="flex items-center gap-1"><Mail size={10} /> {u.email}</span>
                  <span className="flex items-center gap-1"><Calendar size={10} /> {new Date(u.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold capitalize ${u.role === 'admin' ? 'bg-amber-50 text-amber-700' : 'bg-surface-100 text-surface-600'}`}>
              {u.role}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
