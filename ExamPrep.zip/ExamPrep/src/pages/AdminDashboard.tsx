import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { Link } from 'react-router-dom';
import { Users, BookOpen, FileText, StickyNote, TrendingUp, Activity } from 'lucide-react';
import { useAdminCheck } from '../hooks/useAdminCheck';
import { useAuth } from '../context/AuthContext';
import { Loader2 } from 'lucide-react';

export default function AdminDashboard() {
  const { user } = useAuth();
  const { isAdmin, checking } = useAdminCheck(user?.id);
  const [stats, setStats] = useState({
    totalUsers: 0, totalQuizzes: 0, totalPYQs: 0, totalNotes: 0, totalAttempts: 0,
  });

  useEffect(() => {
    if (!isAdmin) return;
    const fetchStats = async () => {
      const [
        { count: users }, { count: quizzes }, { count: pyqs },
        { count: notes }, { count: attempts },
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('quizzes').select('*', { count: 'exact', head: true }),
        supabase.from('pyqs').select('*', { count: 'exact', head: true }),
        supabase.from('notes').select('*', { count: 'exact', head: true }),
        supabase.from('quiz_attempts').select('*', { count: 'exact', head: true }),
      ]);
      setStats({
        totalUsers: users || 0, totalQuizzes: quizzes || 0,
        totalPYQs: pyqs || 0, totalNotes: notes || 0, totalAttempts: attempts || 0,
      });
    };
    fetchStats();
  }, [isAdmin]);

  if (checking) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }
  if (!isAdmin) return null;

  const cards = [
    { label: 'Total Users', value: stats.totalUsers, icon: Users, path: '/admin/users', color: 'bg-blue-50 text-blue-600' },
    { label: 'Quizzes', value: stats.totalQuizzes, icon: BookOpen, path: '/admin/quizzes', color: 'bg-primary-50 text-primary-600' },
    { label: 'PYQs', value: stats.totalPYQs, icon: FileText, path: '/admin/pyqs', color: 'bg-red-50 text-red-600' },
    { label: 'Notes', value: stats.totalNotes, icon: StickyNote, path: '/admin/notes', color: 'bg-amber-50 text-amber-600' },
    { label: 'Attempts', value: stats.totalAttempts, icon: Activity, path: '#', color: 'bg-emerald-50 text-emerald-600' },
  ];

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
          <TrendingUp size={20} className="text-amber-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Admin Dashboard</h1>
          <p className="text-sm text-surface-500">Platform overview and analytics</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {cards.map((card) => (
          <Link key={card.label} to={card.path}
            className="bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg transition-all">
            <div className={`w-12 h-12 rounded-xl ${card.color} flex items-center justify-center mb-4`}>
              <card.icon size={24} />
            </div>
            <div className="text-3xl font-bold text-surface-900 mb-1">{card.value}</div>
            <div className="text-sm text-surface-500">{card.label}</div>
          </Link>
        ))}
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <Link to="/admin/classes" className="block bg-white rounded-xl border border-surface-200 p-4 hover:border-primary-300 transition-colors">
          <h3 className="font-semibold text-surface-900">Manage Classes</h3>
          <p className="text-sm text-surface-500">Add or edit classes</p>
        </Link>
        <Link to="/admin/subjects" className="block bg-white rounded-xl border border-surface-200 p-4 hover:border-primary-300 transition-colors">
          <h3 className="font-semibold text-surface-900">Manage Subjects</h3>
          <p className="text-sm text-surface-500">Add or edit subjects</p>
        </Link>
        <Link to="/admin/topics" className="block bg-white rounded-xl border border-surface-200 p-4 hover:border-primary-300 transition-colors">
          <h3 className="font-semibold text-surface-900">Manage Topics</h3>
          <p className="text-sm text-surface-500">Add or edit topics</p>
        </Link>
        <Link to="/admin/quizzes" className="block bg-white rounded-xl border border-surface-200 p-4 hover:border-primary-300 transition-colors">
          <h3 className="font-semibold text-surface-900">Manage Quizzes</h3>
          <p className="text-sm text-surface-500">Add quizzes and questions</p>
        </Link>
      </div>
    </div>
  );
}
