import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { Class } from '../types';
import ClassCard from '../components/ClassCard';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, GraduationCap } from 'lucide-react';

export default function Classes() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchClasses = async () => {
      const { data } = await supabase.from('classes').select('*').order('name');
      setClasses(data as Class[] || []);
      setLoading(false);
    };
    fetchClasses();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <Breadcrumb items={[{ label: 'Classes' }]} />
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center">
          <GraduationCap size={20} className="text-primary-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Classes</h1>
          <p className="text-sm text-surface-500">Select a class to browse subjects</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {classes.map((cls) => (
          <ClassCard key={cls.id} cls={cls} />
        ))}
      </div>
    </div>
  );
}
