import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { PYQ, Subject } from '../types';
import { Plus, Trash2, X, Check } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminPYQs() {
  const [pyqs, setPyqs] = useState<PYQ[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newYear, setNewYear] = useState(new Date().getFullYear().toString());
  const [selectedSubject, setSelectedSubject] = useState('');
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    const [{ data: s }, { data: p }] = await Promise.all([
      supabase.from('subjects').select('*').order('name'),
      supabase.from('pyqs').select('*, subjects(name)').order('year', { ascending: false }),
    ]);
    setSubjects(s as Subject[] || []);
    setPyqs(p as PYQ[] || []);
    setLoading(false);
  };

  const addPYQ = async () => {
    if (!newTitle.trim() || !selectedSubject || !file) return;
    const filePath = `${selectedSubject}/${Date.now()}_${file.name}`;
    const { error: uploadError } = await supabase.storage.from('pyqs').upload(filePath, file);
    if (uploadError) { alert('Upload failed'); return; }
    await supabase.from('pyqs').insert({ title: newTitle, year: parseInt(newYear), subject_id: selectedSubject, file_path: filePath });
    setNewTitle(''); setNewYear(new Date().getFullYear().toString()); setSelectedSubject(''); setFile(null); setShowAdd(false);
    fetchData();
  };

  const deletePYQ = async (pyq: PYQ) => {
    if (!confirm('Delete this PYQ?')) return;
    await supabase.storage.from('pyqs').remove([pyq.file_path]);
    await supabase.from('pyqs').delete().eq('id', pyq.id);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage PYQs</h1>
          <p className="text-sm text-surface-500">Upload and manage previous year questions</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-xl">
          <Plus size={18} /> Add PYQ
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-2xl border border-surface-200 p-4 mb-4 space-y-3">
          <select value={selectedSubject} onChange={(e) => setSelectedSubject(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm">
            <option value="">Select Subject</option>
            {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <input type="text" placeholder="Title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <input type="number" placeholder="Year" value={newYear} onChange={(e) => setNewYear(e.target.value)} className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <input type="file" accept=".pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} className="w-full text-sm" />
          <div className="flex gap-2">
            <button onClick={addPYQ} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm"><Check size={14} /> Save</button>
            <button onClick={() => setShowAdd(false)} className="flex items-center gap-1 bg-surface-100 text-surface-600 px-3 py-1.5 rounded-lg text-sm"><X size={14} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-surface-200 overflow-hidden">
        {pyqs.map((p) => (
          <div key={p.id} className="flex items-center justify-between p-4 border-b border-surface-100 last:border-0">
            <div>
              <h3 className="font-semibold text-surface-900">{p.title}</h3>
              <p className="text-xs text-surface-500">{(p as any).subjects?.name} • {p.year} • {p.download_count} downloads</p>
            </div>
            <button onClick={() => deletePYQ(p)} className="p-2 text-surface-400 hover:text-red-600"><Trash2 size={16} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}
