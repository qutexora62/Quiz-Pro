import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Quiz, Topic, Subject, Class } from '../types';
import QuizCard from '../components/QuizCard';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, HelpCircle } from 'lucide-react';

export default function Quizzes() {
  const { topicId } = useParams<{ topicId: string }>();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [topic, setTopic] = useState<Topic | null>(null);
  const [subject, setSubject] = useState<Subject | null>(null);
  const [cls, setCls] = useState<Class | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!topicId) return;
      const { data: topicData } = await supabase
        .from('topics')
        .select('*, subjects(*, classes(*))')
        .eq('id', topicId)
        .single();

      if (topicData) {
        setTopic(topicData as Topic);
        setSubject((topicData as any).subjects as Subject);
        setCls((topicData as any).subjects.classes as Class);
      }

      const { data: quizzesData } = await supabase
        .from('quizzes')
        .select('*')
        .eq('topic_id', topicId)
        .order('title');

      setQuizzes(quizzesData as Quiz[] || []);
      setLoading(false);
    };
    fetchData();
  }, [topicId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <Breadcrumb items={[
        { label: 'Classes', path: '/classes' },
        { label: cls?.name || '', path: `/subjects/${cls?.id}` },
        { label: subject?.name || '', path: `/topics/${subject?.id}` },
        { label: topic?.name || 'Quizzes' },
      ]} />
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary-100 flex items-center justify-center">
          <HelpCircle size={20} className="text-primary-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">{topic?.name} Quizzes</h1>
          <p className="text-sm text-surface-500">Select a quiz to start practicing</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {quizzes.map((quiz) => (
          <QuizCard key={quiz.id} quiz={quiz} />
        ))}
      </div>
    </div>
  );
}
