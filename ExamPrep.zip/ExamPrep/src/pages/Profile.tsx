import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { User, Mail, LogOut, Trophy, Clock, BookOpen } from 'lucide-react';
import LoginModal from '../components/LoginModal';

export default function Profile() {
  const { user, session, logout } = useAuth();
  const navigate = useNavigate();
  const [showLogin, setShowLogin] = useState(false);

  if (!session) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <div className="w-20 h-20 rounded-2xl bg-surface-100 flex items-center justify-center mx-auto mb-6">
          <User size={40} className="text-surface-400" />
        </div>
        <h1 className="text-2xl font-bold text-surface-900 mb-2">Sign In Required</h1>
        <p className="text-surface-500 mb-6">Sign in to track your progress and download resources.</p>
        <button
          onClick={() => setShowLogin(true)}
          className="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-8 py-3 rounded-xl transition-colors"
        >
          Sign In / Sign Up
        </button>
        <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold text-surface-900 mb-6">Profile</h1>

      {/* Profile Card */}
      <div className="bg-white rounded-2xl border border-surface-200 p-6 mb-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-2xl bg-primary-100 flex items-center justify-center">
            <span className="text-2xl font-bold text-primary-700">
              {(user?.full_name || user?.email || 'U')[0].toUpperCase()}
            </span>
          </div>
          <div>
            <h2 className="text-xl font-bold text-surface-900">{user?.full_name || 'Student'}</h2>
            <div className="flex items-center gap-2 text-sm text-surface-500">
              <Mail size={14} />
              {user?.email}
            </div>
            <span className="inline-block mt-1 px-2.5 py-0.5 bg-primary-50 text-primary-700 text-xs font-semibold rounded-full capitalize">
              {user?.role}
            </span>
          </div>
        </div>

        <button
          onClick={async () => { await logout(); navigate('/'); }}
          className="flex items-center gap-2 w-full justify-center bg-red-50 hover:bg-red-100 text-red-600 font-semibold py-2.5 rounded-xl transition-colors"
        >
          <LogOut size={18} />
          Sign Out
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-2xl border border-surface-200 p-4 text-center">
          <Trophy size={20} className="text-amber-500 mx-auto mb-2" />
          <div className="text-xl font-bold text-surface-900">0</div>
          <div className="text-xs text-surface-500">Quizzes</div>
        </div>
        <div className="bg-white rounded-2xl border border-surface-200 p-4 text-center">
          <Clock size={20} className="text-primary-500 mx-auto mb-2" />
          <div className="text-xl font-bold text-surface-900">0</div>
          <div className="text-xs text-surface-500">Hours</div>
        </div>
        <div className="bg-white rounded-2xl border border-surface-200 p-4 text-center">
          <BookOpen size={20} className="text-emerald-500 mx-auto mb-2" />
          <div className="text-xl font-bold text-surface-900">0</div>
          <div className="text-xs text-surface-500">Downloads</div>
        </div>
      </div>
    </div>
  );
}
