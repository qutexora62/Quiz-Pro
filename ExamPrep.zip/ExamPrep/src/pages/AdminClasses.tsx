import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { Class } from '../types';
import { Plus, Trash2, Edit2, X, Check } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminClasses() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { fetchClasses(); }, []);

  const fetchClasses = async () => {
    const { data } = await supabase.from('classes').select('*').order('name');
    setClasses(data as Class[] || []);
    setLoading(false);
  };

  const addClass = async () => {
    if (!newName.trim()) return;
    await supabase.from('classes').insert({ name: newName, description: newDesc || null });
    setNewName(''); setNewDesc(''); setShowAdd(false);
    fetchClasses();
  };

  const updateClass = async (id: string) => {
    await supabase.from('classes').update({ name: newName, description: newDesc || null }).eq('id', id);
    setEditing(null);
    fetchClasses();
  };

  const deleteClass = async (id: string) => {
    if (!confirm('Delete this class?')) return;
    await supabase.from('classes').delete().eq('id', id);
    fetchClasses();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage Classes</h1>
          <p className="text-sm text-surface-500">Add, edit, or remove classes</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-xl transition-colors">
          <Plus size={18} /> Add Class
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-2xl border border-surface-200 p-4 mb-4 space-y-3">
          <input type="text" placeholder="Class name" value={newName} onChange={(e) => setNewName(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm focus:outline-none focus:border-primary-500" />
          <input type="text" placeholder="Description (optional)" value={newDesc} onChange={(e) => setNewDesc(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm focus:outline-none focus:border-primary-500" />
          <div className="flex gap-2">
            <button onClick={addClass} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm font-medium"><Check size={14} /> Save</button>
            <button onClick={() => setShowAdd(false)} className="flex items-center gap-1 bg-surface-100 text-surface-600 px-3 py-1.5 rounded-lg text-sm font-medium"><X size={14} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-surface-200 overflow-hidden">
        {classes.map((cls) => (
          <div key={cls.id} className="flex items-center justify-between p-4 border-b border-surface-100 last:border-0">
            {editing === cls.id ? (
              <div className="flex-1 flex items-center gap-3">
                <input type="text" defaultValue={cls.name} onChange={(e) => setNewName(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-surface-50 border border-surface-200 rounded-lg text-sm" />
                <button onClick={() => updateClass(cls.id)} className="text-green-600"><Check size={18} /></button>
                <button onClick={() => setEditing(null)} className="text-surface-400"><X size={18} /></button>
              </div>
            ) : (
              <>
                <div>
                  <h3 className="font-semibold text-surface-900">{cls.name}</h3>
                  {cls.description && <p className="text-sm text-surface-500">{cls.description}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => { setEditing(cls.id); setNewName(cls.name); setNewDesc(cls.description || ''); }}
                    className="p-2 text-surface-400 hover:text-primary-600"><Edit2 size={16} /></button>
                  <button onClick={() => deleteClass(cls.id)} className="p-2 text-surface-400 hover:text-red-600"><Trash2 size={16} /></button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
