import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Note, Topic, Subject, Class } from '../types';
import NoteCard from '../components/NoteCard';
import ProtectedDownload from '../components/ProtectedDownload';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, StickyNote } from 'lucide-react';

export default function Notes() {
  const { topicId } = useParams<{ topicId: string }>();
  const [notes, setNotes] = useState<Note[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string>(topicId || '');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const { data: topicsData } = await supabase
        .from('topics')
        .select('*, subjects(*, classes(*))')
        .order('name');
      setTopics(topicsData as Topic[] || []);

      if (selectedTopic) {
        const { data } = await supabase
          .from('notes')
          .select('*')
          .eq('topic_id', selectedTopic)
          .order('title');
        setNotes(data as Note[] || []);
      }
      setLoading(false);
    };
    fetchData();
  }, [selectedTopic]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <Breadcrumb items={[{ label: 'Notes' }]} />
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
          <StickyNote size={20} className="text-amber-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Handwritten Notes</h1>
          <p className="text-sm text-surface-500">Download notes for quick revision</p>
        </div>
      </div>

      {/* Topic Filter */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6 pb-2">
        {topics.map((t) => (
          <button
            key={t.id}
            onClick={() => setSelectedTopic(t.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              selectedTopic === t.id
                ? 'bg-primary-600 text-white'
                : 'bg-white border border-surface-200 text-surface-600 hover:bg-surface-50'
            }`}
          >
            {t.name}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {notes.map((note) => (
          <ProtectedDownload key={note.id} filePath={note.file_path} bucket="notes">
            <NoteCard note={note} onDownload={() => {}} />
          </ProtectedDownload>
        ))}
      </div>

      {notes.length === 0 && selectedTopic && (
        <div className="text-center py-20 text-surface-500">
          No notes available for this topic yet.
        </div>
      )}
    </div>
  );
}
