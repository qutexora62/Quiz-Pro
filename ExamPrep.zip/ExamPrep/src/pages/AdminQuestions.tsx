import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Question } from '../types';
import { Plus, Trash2, X, Check } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminQuestions() {
  const { quizId } = useParams<{ quizId: string }>();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    question_text: '', option_a: '', option_b: '', option_c: '', option_d: '',
    correct_option: 'a', explanation: '',
  });

  useEffect(() => { fetchQuestions(); }, [quizId]);

  const fetchQuestions = async () => {
    const { data } = await supabase.from('questions').select('*').eq('quiz_id', quizId).order('id');
    setQuestions(data as Question[] || []);
    setLoading(false);
  };

  const addQuestion = async () => {
    if (!form.question_text.trim() || !form.option_a.trim()) return;
    await supabase.from('questions').insert({ ...form, quiz_id: quizId });
    setForm({ question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_option: 'a', explanation: '' });
    setShowAdd(false);
    fetchQuestions();
  };

  const deleteQuestion = async (id: string) => {
    if (!confirm('Delete this question?')) return;
    await supabase.from('questions').delete().eq('id', id);
    fetchQuestions();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage Questions</h1>
          <p className="text-sm text-surface-500">{questions.length} questions in this quiz</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-xl">
          <Plus size={18} /> Add Question
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-2xl border border-surface-200 p-4 mb-4 space-y-3">
          <textarea placeholder="Question text" value={form.question_text} onChange={(e) => setForm({ ...form, question_text: e.target.value })}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm h-20" />
          <div className="grid grid-cols-2 gap-3">
            <input placeholder="Option A" value={form.option_a} onChange={(e) => setForm({ ...form, option_a: e.target.value })} className="px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
            <input placeholder="Option B" value={form.option_b} onChange={(e) => setForm({ ...form, option_b: e.target.value })} className="px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
            <input placeholder="Option C" value={form.option_c} onChange={(e) => setForm({ ...form, option_c: e.target.value })} className="px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
            <input placeholder="Option D" value={form.option_d} onChange={(e) => setForm({ ...form, option_d: e.target.value })} className="px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          </div>
          <select value={form.correct_option} onChange={(e) => setForm({ ...form, correct_option: e.target.value as any })}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm">
            <option value="a">Correct: A</option>
            <option value="b">Correct: B</option>
            <option value="c">Correct: C</option>
            <option value="d">Correct: D</option>
          </select>
          <input placeholder="Explanation (optional)" value={form.explanation} onChange={(e) => setForm({ ...form, explanation: e.target.value })}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <div className="flex gap-2">
            <button onClick={addQuestion} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm"><Check size={14} /> Save</button>
            <button onClick={() => setShowAdd(false)} className="flex items-center gap-1 bg-surface-100 text-surface-600 px-3 py-1.5 rounded-lg text-sm"><X size={14} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {questions.map((q, i) => (
          <div key={q.id} className="bg-white rounded-2xl border border-surface-200 p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <p className="font-medium text-surface-900 mb-2"><span className="text-primary-600 font-bold mr-2">{i + 1}.</span>{q.question_text}</p>
                <div className="grid grid-cols-2 gap-2 text-sm text-surface-600 mb-2">
                  <div className={q.correct_option === 'a' ? 'text-green-600 font-semibold' : ''}>A. {q.option_a}</div>
                  <div className={q.correct_option === 'b' ? 'text-green-600 font-semibold' : ''}>B. {q.option_b}</div>
                  <div className={q.correct_option === 'c' ? 'text-green-600 font-semibold' : ''}>C. {q.option_c}</div>
                  <div className={q.correct_option === 'd' ? 'text-green-600 font-semibold' : ''}>D. {q.option_d}</div>
                </div>
              </div>
              <button onClick={() => deleteQuestion(q.id)} className="p-2 text-surface-400 hover:text-red-600"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
