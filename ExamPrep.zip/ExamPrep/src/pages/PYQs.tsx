import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { PYQ, Subject, Class } from '../types';
import PYQCard from '../components/PYQCard';
import ProtectedDownload from '../components/ProtectedDownload';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, FileText } from 'lucide-react';

export default function PYQs() {
  const { subjectId } = useParams<{ subjectId: string }>();
  const [pyqs, setPyqs] = useState<PYQ[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>(subjectId || '');
  const [cls, setCls] = useState<Class | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const { data: subjectsData } = await supabase.from('subjects').select('*, classes(*)').order('name');
      setSubjects(subjectsData as Subject[] || []);

      if (subjectsData && subjectsData.length > 0) {
        const first = subjectsData[0] as any;
        setCls(first.classes as Class);
      }

      if (selectedSubject) {
        const { data } = await supabase
          .from('pyqs')
          .select('*')
          .eq('subject_id', selectedSubject)
          .order('year', { ascending: false });
        setPyqs(data as PYQ[] || []);
      }
      setLoading(false);
    };
    fetchData();
  }, [selectedSubject]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <Breadcrumb items={[{ label: 'PYQs' }]} />
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
          <FileText size={20} className="text-red-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Previous Year Questions</h1>
          <p className="text-sm text-surface-500">Download official exam papers</p>
        </div>
      </div>

      {/* Subject Filter */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6 pb-2">
        {subjects.map((s) => (
          <button
            key={s.id}
            onClick={() => setSelectedSubject(s.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              selectedSubject === s.id
                ? 'bg-primary-600 text-white'
                : 'bg-white border border-surface-200 text-surface-600 hover:bg-surface-50'
            }`}
          >
            {s.name}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {pyqs.map((pyq) => (
          <ProtectedDownload key={pyq.id} filePath={pyq.file_path} bucket="pyqs">
            <PYQCard pyq={pyq} onDownload={() => {}} />
          </ProtectedDownload>
        ))}
      </div>

      {pyqs.length === 0 && selectedSubject && (
        <div className="text-center py-20 text-surface-500">
          No PYQs available for this subject yet.
        </div>
      )}
    </div>
  );
}
