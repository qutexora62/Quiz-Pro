import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { Note, Topic } from '../types';
import { Plus, Trash2, X, Check } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminNotes() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    const [{ data: t }, { data: n }] = await Promise.all([
      supabase.from('topics').select('*').order('name'),
      supabase.from('notes').select('*, topics(name)').order('title'),
    ]);
    setTopics(t as Topic[] || []);
    setNotes(n as Note[] || []);
    setLoading(false);
  };

  const addNote = async () => {
    if (!newTitle.trim() || !selectedTopic || !file) return;
    const filePath = `${selectedTopic}/${Date.now()}_${file.name}`;
    const { error: uploadError } = await supabase.storage.from('notes').upload(filePath, file);
    if (uploadError) { alert('Upload failed'); return; }
    await supabase.from('notes').insert({ title: newTitle, topic_id: selectedTopic, file_path: filePath });
    setNewTitle(''); setSelectedTopic(''); setFile(null); setShowAdd(false);
    fetchData();
  };

  const deleteNote = async (note: Note) => {
    if (!confirm('Delete this note?')) return;
    await supabase.storage.from('notes').remove([note.file_path]);
    await supabase.from('notes').delete().eq('id', note.id);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage Notes</h1>
          <p className="text-sm text-surface-500">Upload and manage handwritten notes</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-xl">
          <Plus size={18} /> Add Note
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-2xl border border-surface-200 p-4 mb-4 space-y-3">
          <select value={selectedTopic} onChange={(e) => setSelectedTopic(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm">
            <option value="">Select Topic</option>
            {topics.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <input type="text" placeholder="Title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] || null)} className="w-full text-sm" />
          <div className="flex gap-2">
            <button onClick={addNote} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm"><Check size={14} /> Save</button>
            <button onClick={() => setShowAdd(false)} className="flex items-center gap-1 bg-surface-100 text-surface-600 px-3 py-1.5 rounded-lg text-sm"><X size={14} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-surface-200 overflow-hidden">
        {notes.map((n) => (
          <div key={n.id} className="flex items-center justify-between p-4 border-b border-surface-100 last:border-0">
            <div>
              <h3 className="font-semibold text-surface-900">{n.title}</h3>
              <p className="text-xs text-surface-500">{(n as any).topics?.name} • {n.download_count} downloads</p>
            </div>
            <button onClick={() => deleteNote(n)} className="p-2 text-surface-400 hover:text-red-600"><Trash2 size={16} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}
