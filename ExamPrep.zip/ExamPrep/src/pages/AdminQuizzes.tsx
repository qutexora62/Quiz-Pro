import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Quiz, Topic } from '../types';
import { Plus, Trash2, ArrowRight, X, Check } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminQuizzes() {
  const navigate = useNavigate();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newTime, setNewTime] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    const [{ data: t }, { data: q }] = await Promise.all([
      supabase.from('topics').select('*').order('name'),
      supabase.from('quizzes').select('*, topics(name)').order('title'),
    ]);
    setTopics(t as Topic[] || []);
    setQuizzes(q as Quiz[] || []);
    setLoading(false);
  };

  const addQuiz = async () => {
    if (!newTitle.trim() || !selectedTopic) return;
    await supabase.from('quizzes').insert({
      title: newTitle, description: newDesc || null, topic_id: selectedTopic,
      time_limit_minutes: newTime ? parseInt(newTime) : null,
    });
    setNewTitle(''); setNewDesc(''); setNewTime(''); setSelectedTopic(''); setShowAdd(false);
    fetchData();
  };

  const deleteQuiz = async (id: string) => {
    if (!confirm('Delete this quiz and all its questions?')) return;
    await supabase.from('quizzes').delete().eq('id', id);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage Quizzes</h1>
          <p className="text-sm text-surface-500">Create and manage quizzes</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-xl">
          <Plus size={18} /> Add Quiz
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-2xl border border-surface-200 p-4 mb-4 space-y-3">
          <select value={selectedTopic} onChange={(e) => setSelectedTopic(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm">
            <option value="">Select Topic</option>
            {topics.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <input type="text" placeholder="Quiz title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <input type="text" placeholder="Description" value={newDesc} onChange={(e) => setNewDesc(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <input type="number" placeholder="Time limit (minutes)" value={newTime} onChange={(e) => setNewTime(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <div className="flex gap-2">
            <button onClick={addQuiz} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm"><Check size={14} /> Save</button>
            <button onClick={() => setShowAdd(false)} className="flex items-center gap-1 bg-surface-100 text-surface-600 px-3 py-1.5 rounded-lg text-sm"><X size={14} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-surface-200 overflow-hidden">
        {quizzes.map((q) => (
          <div key={q.id} className="flex items-center justify-between p-4 border-b border-surface-100 last:border-0">
            <div>
              <h3 className="font-semibold text-surface-900">{q.title}</h3>
              <p className="text-xs text-surface-500">{(q as any).topics?.name} {q.time_limit_minutes && `• ${q.time_limit_minutes} min`}</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => navigate(`/admin/questions/${q.id}`)} className="p-2 text-surface-400 hover:text-primary-600"><ArrowRight size={16} /></button>
              <button onClick={() => deleteQuiz(q.id)} className="p-2 text-surface-400 hover:text-red-600"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
