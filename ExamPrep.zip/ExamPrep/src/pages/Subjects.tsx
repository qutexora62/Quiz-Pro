import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import type { Subject, Class } from '../types';
import SubjectCard from '../components/SubjectCard';
import Breadcrumb from '../components/Breadcrumb';
import { Loader2, BookOpen } from 'lucide-react';

export default function Subjects() {
  const { classId } = useParams<{ classId: string }>();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [cls, setCls] = useState<Class | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!classId) return;
      const [{ data: classData }, { data: subjectsData }] = await Promise.all([
        supabase.from('classes').select('*').eq('id', classId).single(),
        supabase.from('subjects').select('*').eq('class_id', classId).order('name'),
      ]);
      setCls(classData as Class);
      setSubjects(subjectsData as Subject[] || []);
      setLoading(false);
    };
    fetchData();
  }, [classId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <Breadcrumb items={[
        { label: 'Classes', path: '/classes' },
        { label: cls?.name || 'Subjects' },
      ]} />
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center">
          <BookOpen size={20} className="text-indigo-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-surface-900">{cls?.name} Subjects</h1>
          <p className="text-sm text-surface-500">Select a subject to explore topics</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map((subject) => (
          <SubjectCard key={subject.id} subject={subject} classId={classId!} />
        ))}
      </div>
    </div>
  );
}
