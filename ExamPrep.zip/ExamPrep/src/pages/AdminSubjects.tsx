import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { Subject, Class } from '../types';
import { Plus, Trash2, X, Check } from 'lucide-react';
import { Loader2 } from 'lucide-react';

export default function AdminSubjects() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [selectedClass, setSelectedClass] = useState('');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    const [{ data: c }, { data: s }] = await Promise.all([
      supabase.from('classes').select('*').order('name'),
      supabase.from('subjects').select('*, classes(name)').order('name'),
    ]);
    setClasses(c as Class[] || []);
    setSubjects(s as Subject[] || []);
    setLoading(false);
  };

  const addSubject = async () => {
    if (!newName.trim() || !selectedClass) return;
    await supabase.from('subjects').insert({ name: newName, description: newDesc || null, class_id: selectedClass });
    setNewName(''); setNewDesc(''); setSelectedClass(''); setShowAdd(false);
    fetchData();
  };

  const deleteSubject = async (id: string) => {
    if (!confirm('Delete this subject?')) return;
    await supabase.from('subjects').delete().eq('id', id);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Manage Subjects</h1>
          <p className="text-sm text-surface-500">Organize subjects by class</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold px-4 py-2 rounded-xl">
          <Plus size={18} /> Add Subject
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-2xl border border-surface-200 p-4 mb-4 space-y-3">
          <select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm">
            <option value="">Select Class</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input type="text" placeholder="Subject name" value={newName} onChange={(e) => setNewName(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <input type="text" placeholder="Description" value={newDesc} onChange={(e) => setNewDesc(e.target.value)}
            className="w-full px-4 py-2 bg-surface-50 border border-surface-200 rounded-xl text-sm" />
          <div className="flex gap-2">
            <button onClick={addSubject} className="flex items-center gap-1 bg-green-600 text-white px-3 py-1.5 rounded-lg text-sm"><Check size={14} /> Save</button>
            <button onClick={() => setShowAdd(false)} className="flex items-center gap-1 bg-surface-100 text-surface-600 px-3 py-1.5 rounded-lg text-sm"><X size={14} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-surface-200 overflow-hidden">
        {subjects.map((s) => (
          <div key={s.id} className="flex items-center justify-between p-4 border-b border-surface-100 last:border-0">
            <div>
              <h3 className="font-semibold text-surface-900">{s.name}</h3>
              <p className="text-xs text-surface-500">{(s as any).classes?.name}</p>
            </div>
            <button onClick={() => deleteSubject(s.id)} className="p-2 text-surface-400 hover:text-red-600"><Trash2 size={16} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}
