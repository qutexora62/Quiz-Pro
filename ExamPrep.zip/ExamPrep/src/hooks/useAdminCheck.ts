import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export function useAdminCheck(userId: string | undefined) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (!userId) {
      setChecking(false);
      return;
    }

    const check = async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', userId)
        .single();

      if (!error && data) {
        setIsAdmin(data.role === 'admin');
      }
      setChecking(false);
    };

    check();
  }, [userId]);

  return { isAdmin, checking };
}
