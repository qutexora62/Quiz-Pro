export interface Class {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export interface Subject {
  id: string;
  class_id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export interface Topic {
  id: string;
  subject_id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export interface Quiz {
  id: string;
  topic_id: string;
  title: string;
  description: string | null;
  time_limit_minutes: number | null;
  created_at: string;
}

export interface Question {
  id: string;
  quiz_id: string;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: 'a' | 'b' | 'c' | 'd';
  explanation: string | null;
  created_at: string;
}

export interface PYQ {
  id: string;
  subject_id: string;
  title: string;
  year: number;
  file_path: string;
  download_count: number;
  created_at: string;
}

export interface Note {
  id: string;
  topic_id: string;
  title: string;
  file_path: string;
  download_count: number;
  created_at: string;
}

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  role: 'student' | 'admin';
  created_at: string;
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  quiz_id: string;
  score: number;
  total_questions: number;
  answers: Record<string, string>;
  completed_at: string;
}

export type SearchResult = 
  | { type: 'quiz'; data: Quiz & { topic_name: string; subject_name: string } }
  | { type: 'pyq'; data: PYQ & { subject_name: string; class_name: string } }
  | { type: 'note'; data: Note & { topic_name: string; subject_name: string } }
  | { type: 'topic'; data: Topic & { subject_name: string; class_name: string } };
