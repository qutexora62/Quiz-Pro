export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      classes: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          created_at?: string;
        };
      };
      subjects: {
        Row: {
          id: string;
          class_id: string;
          name: string;
          description: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          class_id: string;
          name: string;
          description?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          class_id?: string;
          name?: string;
          description?: string | null;
          created_at?: string;
        };
      };
      topics: {
        Row: {
          id: string;
          subject_id: string;
          name: string;
          description: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          subject_id: string;
          name: string;
          description?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          subject_id?: string;
          name?: string;
          description?: string | null;
          created_at?: string;
        };
      };
      quizzes: {
        Row: {
          id: string;
          topic_id: string;
          title: string;
          description: string | null;
          time_limit_minutes: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          topic_id: string;
          title: string;
          description?: string | null;
          time_limit_minutes?: number | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          topic_id?: string;
          title?: string;
          description?: string | null;
          time_limit_minutes?: number | null;
          created_at?: string;
        };
      };
      questions: {
        Row: {
          id: string;
          quiz_id: string;
          question_text: string;
          option_a: string;
          option_b: string;
          option_c: string;
          option_d: string;
          correct_option: string;
          explanation: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          quiz_id: string;
          question_text: string;
          option_a: string;
          option_b: string;
          option_c: string;
          option_d: string;
          correct_option: string;
          explanation?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          quiz_id?: string;
          question_text?: string;
          option_a?: string;
          option_b?: string;
          option_c?: string;
          option_d?: string;
          correct_option?: string;
          explanation?: string | null;
          created_at?: string;
        };
      };
      pyqs: {
        Row: {
          id: string;
          subject_id: string;
          title: string;
          year: number;
          file_path: string;
          download_count: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          subject_id: string;
          title: string;
          year: number;
          file_path: string;
          download_count?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          subject_id?: string;
          title?: string;
          year?: number;
          file_path?: string;
          download_count?: number;
          created_at?: string;
        };
      };
      notes: {
        Row: {
          id: string;
          topic_id: string;
          title: string;
          file_path: string;
          download_count: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          topic_id: string;
          title: string;
          file_path: string;
          download_count?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          topic_id?: string;
          title?: string;
          file_path?: string;
          download_count?: number;
          created_at?: string;
        };
      };
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          role: string;
          created_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          role?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          role?: string;
          created_at?: string;
        };
      };
      quiz_attempts: {
        Row: {
          id: string;
          user_id: string;
          quiz_id: string;
          score: number;
          total_questions: number;
          answers: Json;
          completed_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          quiz_id: string;
          score: number;
          total_questions: number;
          answers: Json;
          completed_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          quiz_id?: string;
          score?: number;
          total_questions?: number;
          answers?: Json;
          completed_at?: string;
        };
      };
    };
  };
}
