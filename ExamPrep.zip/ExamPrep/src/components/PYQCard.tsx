import { FileText, Calendar, Download } from 'lucide-react';
import type { PYQ } from '../types';

interface PYQCardProps {
  pyq: PYQ;
  onDownload: () => void;
}

export default function PYQCard({ pyq, onDownload }: PYQCardProps) {
  return (
    <div className="bg-white rounded-2xl border border-surface-200 p-5 hover:shadow-md transition-all">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
          <FileText size={24} className="text-red-500" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-surface-900 mb-1 truncate">{pyq.title}</h3>
          <div className="flex items-center gap-2 text-sm text-surface-500 mb-3">
            <Calendar size={14} />
            <span>{pyq.year}</span>
          </div>
          <button
            onClick={onDownload}
            className="flex items-center gap-2 px-4 py-2 bg-primary-50 text-primary-700 text-sm font-medium rounded-lg hover:bg-primary-100 transition-colors"
          >
            <Download size={16} />
            Download PDF
          </button>
        </div>
      </div>
    </div>
  );
}
