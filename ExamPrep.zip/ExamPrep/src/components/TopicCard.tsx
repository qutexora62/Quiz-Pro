import { Link } from 'react-router-dom';
import { Layers, ArrowRight } from 'lucide-react';
import type { Topic } from '../types';

interface TopicCardProps {
  topic: Topic;
}

export default function TopicCard({ topic }: TopicCardProps) {
  return (
    <Link
      to={`/quizzes/${topic.id}`}
      className="group block bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg hover:border-primary-200 transition-all duration-300"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center group-hover:bg-emerald-500 transition-colors">
          <Layers size={24} className="text-emerald-600 group-hover:text-white" />
        </div>
        <ArrowRight size={20} className="text-surface-300 group-hover:text-emerald-500 group-hover:translate-x-1 transition-all" />
      </div>
      <h3 className="font-bold text-lg text-surface-900 mb-1">{topic.name}</h3>
      {topic.description && (
        <p className="text-sm text-surface-500 line-clamp-2">{topic.description}</p>
      )}
    </Link>
  );
}
