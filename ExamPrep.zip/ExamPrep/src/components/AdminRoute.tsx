import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useAdminCheck } from '../hooks/useAdminCheck';
import { Loader2 } from 'lucide-react';

export default function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, checking } = useAdminCheck(user?.id);

  if (authLoading || checking) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="animate-spin text-primary-500" size={32} />
      </div>
    );
  }

  if (!user || !isAdmin) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
