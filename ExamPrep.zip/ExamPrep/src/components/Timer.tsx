import { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';

interface TimerProps {
  minutes: number;
  onTimeUp: () => void;
  isRunning: boolean;
}

export default function Timer({ minutes, onTimeUp, isRunning }: TimerProps) {
  const [secondsLeft, setSecondsLeft] = useState(minutes * 60);

  useEffect(() => {
    setSecondsLeft(minutes * 60);
  }, [minutes]);

  useEffect(() => {
    if (!isRunning || secondsLeft <= 0) return;

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, secondsLeft, onTimeUp]);

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;
  const isLow = secondsLeft < 60;

  return (
    <div className={`flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-bold text-lg ${
      isLow ? 'bg-red-50 text-red-600 animate-pulse' : 'bg-surface-100 text-surface-700'
    }`}>
      <Clock size={20} className={isLow ? 'text-red-500' : 'text-surface-400'} />
      <span>{String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}</span>
    </div>
  );
}
