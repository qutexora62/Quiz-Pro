import { useState } from 'react';
import type { Question } from '../types';

interface QuestionCardProps {
  question: Question;
  index: number;
  selectedAnswer: string | null;
  onSelect: (option: string) => void;
  showCorrect?: boolean;
}

const options = [
  { key: 'a', label: 'A' },
  { key: 'b', label: 'B' },
  { key: 'c', label: 'C' },
  { key: 'd', label: 'D' },
];

export default function QuestionCard({ question, index, selectedAnswer, onSelect, showCorrect }: QuestionCardProps) {
  return (
    <div className="bg-white rounded-2xl border border-surface-200 p-6 mb-4">
      <div className="flex items-start gap-3 mb-5">
        <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary-100 text-primary-700 font-bold text-sm flex items-center justify-center">
          {index + 1}
        </span>
        <p className="text-surface-900 font-medium leading-relaxed pt-1">{question.question_text}</p>
      </div>

      <div className="space-y-3 ml-11">
        {options.map((opt) => {
          const isSelected = selectedAnswer === opt.key;
          const isCorrect = showCorrect && opt.key === question.correct_option;
          const isWrong = showCorrect && isSelected && opt.key !== question.correct_option;

          let btnClass = 'w-full text-left px-4 py-3 rounded-xl border-2 transition-all text-sm ';
          if (isCorrect) {
            btnClass += 'border-green-500 bg-green-50 text-green-800';
          } else if (isWrong) {
            btnClass += 'border-red-500 bg-red-50 text-red-800';
          } else if (isSelected) {
            btnClass += 'border-primary-500 bg-primary-50 text-primary-800';
          } else {
            btnClass += 'border-surface-200 hover:border-primary-300 hover:bg-surface-50';
          }

          return (
            <button
              key={opt.key}
              onClick={() => !showCorrect && onSelect(opt.key)}
              disabled={showCorrect}
              className={btnClass}
            >
              <span className="font-semibold mr-2">{opt.label}.</span>
              {question[`option_${opt.key}` as keyof Question]}
            </button>
          );
        })}
      </div>

      {showCorrect && question.explanation && (
        <div className="mt-4 ml-11 p-4 bg-blue-50 rounded-xl text-sm text-blue-800">
          <span className="font-semibold">Explanation:</span> {question.explanation}
        </div>
      )}
    </div>
  );
}
