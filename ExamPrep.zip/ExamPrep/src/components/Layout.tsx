import { Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import BottomNav from './BottomNav';
import Sidebar from './Sidebar';
import SearchBar from './SearchBar';
import InstallButton from './InstallButton';

export default function Layout() {
  const { user } = useAuth();
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith('/admin');

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block fixed left-0 top-0 h-full w-64 bg-white border-r border-surface-200 z-40">
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="lg:ml-64 pb-20 lg:pb-0">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-surface-200 px-4 py-3">
          <div className="max-w-5xl mx-auto flex items-center gap-4">
            <div className="lg:hidden flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary-500 flex items-center justify-center">
                <span className="text-white font-bold text-sm">E</span>
              </div>
              <span className="font-bold text-lg text-surface-900">ExamPrep</span>
            </div>
            <div className="flex-1 max-w-xl">
              <SearchBar />
            </div>
            <div className="hidden sm:flex items-center gap-3">
              <InstallButton />
              {user && (
                <span className="text-sm text-surface-600 font-medium">
                  {user.full_name || user.email}
                </span>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="max-w-5xl mx-auto px-4 py-6 animate-fade-in">
          <Outlet />
        </main>
      </div>

      {/* Mobile Bottom Nav */}
      {!isAdminRoute && <BottomNav />}
    </div>
  );
}
