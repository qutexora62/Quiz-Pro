import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import LoginModal from './LoginModal';
import { supabase } from '../lib/supabaseClient';

interface ProtectedDownloadProps {
  filePath: string;
  bucket: 'pyqs' | 'notes';
  onDownload?: () => void;
  children: React.ReactNode;
}

export default function ProtectedDownload({ filePath, bucket, onDownload, children }: ProtectedDownloadProps) {
  const { user } = useAuth();
  const [showLogin, setShowLogin] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleClick = async () => {
    if (!user) {
      setShowLogin(true);
      return;
    }

    setDownloading(true);
    try {
      const { data, error } = await supabase.storage
        .from(bucket)
        .createSignedUrl(filePath, 60);

      if (error) throw error;
      if (data?.signedUrl) {
        // Increment download count
        await supabase.rpc('increment_download', { 
          table_name: bucket,
          row_id: filePath 
        });

        const link = document.createElement('a');
        link.href = data.signedUrl;
        link.download = filePath.split('/').pop() || 'download';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        onDownload?.();
      }
    } catch (err) {
      console.error('Download failed:', err);
      alert('Failed to download file. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <>
      <div onClick={handleClick} className={downloading ? 'opacity-50 pointer-events-none' : 'cursor-pointer'}>
        {children}
      </div>
      <LoginModal 
        isOpen={showLogin} 
        onClose={() => setShowLogin(false)} 
        onSuccess={handleClick}
      />
    </>
  );
}
