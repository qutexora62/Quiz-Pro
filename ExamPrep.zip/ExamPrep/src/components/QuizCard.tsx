import { Link } from 'react-router-dom';
import { Clock, HelpCircle, ArrowRight } from 'lucide-react';
import type { Quiz } from '../types';

interface QuizCardProps {
  quiz: Quiz;
  topicName?: string;
}

export default function QuizCard({ quiz, topicName }: QuizCardProps) {
  return (
    <Link
      to={`/quiz/${quiz.id}`}
      className="group block bg-white rounded-2xl border border-surface-200 p-5 hover:shadow-lg hover:border-primary-200 transition-all duration-300"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center group-hover:bg-primary-500 group-hover:text-white transition-colors">
          <HelpCircle size={20} className="text-primary-600 group-hover:text-white" />
        </div>
        <ArrowRight size={18} className="text-surface-300 group-hover:text-primary-500 group-hover:translate-x-1 transition-all" />
      </div>
      <h3 className="font-semibold text-surface-900 mb-1 line-clamp-1">{quiz.title}</h3>
      {topicName && <p className="text-xs text-surface-500 mb-2">{topicName}</p>}
      {quiz.description && (
        <p className="text-sm text-surface-500 line-clamp-2 mb-3">{quiz.description}</p>
      )}
      {quiz.time_limit_minutes && (
        <div className="flex items-center gap-1.5 text-xs text-amber-600 bg-amber-50 w-fit px-2.5 py-1 rounded-full">
          <Clock size={12} />
          <span>{quiz.time_limit_minutes} min</span>
        </div>
      )}
    </Link>
  );
}
