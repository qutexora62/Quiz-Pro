import { StickyNote, Download } from 'lucide-react';
import type { Note } from '../types';

interface NoteCardProps {
  note: Note;
  onDownload: () => void;
}

export default function NoteCard({ note, onDownload }: NoteCardProps) {
  return (
    <div className="bg-white rounded-2xl border border-surface-200 p-5 hover:shadow-md transition-all">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center flex-shrink-0">
          <StickyNote size={24} className="text-amber-500" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-surface-900 mb-3 truncate">{note.title}</h3>
          <button
            onClick={onDownload}
            className="flex items-center gap-2 px-4 py-2 bg-primary-50 text-primary-700 text-sm font-medium rounded-lg hover:bg-primary-100 transition-colors"
          >
            <Download size={16} />
            Download Notes
          </button>
        </div>
      </div>
    </div>
  );
}
