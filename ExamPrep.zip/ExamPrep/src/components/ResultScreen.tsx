import { Link } from 'react-router-dom';
import { Trophy, RotateCcw, Home, CheckCircle, XCircle, HelpCircle } from 'lucide-react';
import type { Question } from '../types';

interface ResultScreenProps {
  score: number;
  total: number;
  questions: Question[];
  answers: Record<string, string>;
  onRetry: () => void;
}

export default function ResultScreen({ score, total, questions, answers, onRetry }: ResultScreenProps) {
  const percentage = Math.round((score / total) * 100);
  const correct = questions.filter((q) => answers[q.id] === q.correct_option).length;
  const incorrect = questions.filter((q) => answers[q.id] && answers[q.id] !== q.correct_option).length;
  const unattempted = total - correct - incorrect;

  const getGrade = () => {
    if (percentage >= 90) return { label: 'Outstanding!', color: 'text-green-600', bg: 'bg-green-50' };
    if (percentage >= 75) return { label: 'Great Job!', color: 'text-primary-600', bg: 'bg-primary-50' };
    if (percentage >= 60) return { label: 'Good Effort', color: 'text-amber-600', bg: 'bg-amber-50' };
    return { label: 'Keep Practicing', color: 'text-red-600', bg: 'bg-red-50' };
  };

  const grade = getGrade();

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      {/* Score Card */}
      <div className="bg-white rounded-3xl border border-surface-200 p-8 text-center mb-6">
        <div className={`w-20 h-20 rounded-full ${grade.bg} flex items-center justify-center mx-auto mb-4`}>
          <Trophy size={36} className={grade.color} />
        </div>
        <h2 className={`text-2xl font-bold ${grade.color} mb-1`}>{grade.label}</h2>
        <p className="text-surface-500 text-sm mb-6">You scored {score} out of {total}</p>

        <div className="flex items-center justify-center gap-2 mb-6">
          <div className="text-5xl font-bold text-surface-900">{percentage}</div>
          <div className="text-2xl text-surface-400 font-light">%</div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-green-50 rounded-xl p-3">
            <CheckCircle size={20} className="text-green-600 mx-auto mb-1" />
            <div className="text-lg font-bold text-green-700">{correct}</div>
            <div className="text-xs text-green-600">Correct</div>
          </div>
          <div className="bg-red-50 rounded-xl p-3">
            <XCircle size={20} className="text-red-600 mx-auto mb-1" />
            <div className="text-lg font-bold text-red-700">{incorrect}</div>
            <div className="text-xs text-red-600">Incorrect</div>
          </div>
          <div className="bg-surface-100 rounded-xl p-3">
            <HelpCircle size={20} className="text-surface-500 mx-auto mb-1" />
            <div className="text-lg font-bold text-surface-700">{unattempted}</div>
            <div className="text-xs text-surface-500">Skipped</div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 mb-8">
        <button
          onClick={onRetry}
          className="flex-1 flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 rounded-xl transition-colors"
        >
          <RotateCcw size={18} />
          Retry Quiz
        </button>
        <Link
          to="/classes"
          className="flex-1 flex items-center justify-center gap-2 bg-white border border-surface-200 hover:bg-surface-50 text-surface-700 font-semibold py-3 rounded-xl transition-colors"
        >
          <Home size={18} />
          More Quizzes
        </Link>
      </div>

      {/* Review */}
      <h3 className="font-bold text-lg text-surface-900 mb-4">Answer Review</h3>
      <div className="space-y-3">
        {questions.map((q, i) => {
          const userAns = answers[q.id];
          const isCorrect = userAns === q.correct_option;
          return (
            <div key={q.id} className={`bg-white rounded-xl border p-4 ${isCorrect ? 'border-green-200' : 'border-red-200'}`}>
              <div className="flex items-start gap-3">
                <span className={`flex-shrink-0 w-7 h-7 rounded-lg text-sm font-bold flex items-center justify-center ${
                  isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-surface-900 mb-2">{q.question_text}</p>
                  <div className="flex flex-wrap gap-2 text-xs">
                    <span className="px-2 py-1 rounded-md bg-surface-100 text-surface-600">
                      Your: {userAns?.toUpperCase() || '—'}
                    </span>
                    <span className="px-2 py-1 rounded-md bg-green-100 text-green-700">
                      Correct: {q.correct_option.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
