import { Download } from 'lucide-react';
import { useInstallPrompt } from '../hooks/useInstallPrompt';

export default function InstallButton() {
  const { deferredPrompt, isInstalled, promptInstall } = useInstallPrompt();

  if (isInstalled || !deferredPrompt) return null;

  return (
    <button
      onClick={promptInstall}
      className="flex items-center gap-2 px-3 py-1.5 bg-primary-50 text-primary-700 text-sm font-medium rounded-lg hover:bg-primary-100 transition-colors"
    >
      <Download size={16} />
      <span className="hidden sm:inline">Install App</span>
    </button>
  );
}
