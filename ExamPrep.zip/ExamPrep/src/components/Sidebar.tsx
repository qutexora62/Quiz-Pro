import { Link, useLocation } from 'react-router-dom';
import { Home, BookOpen, FileText, StickyNote, User, Shield, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { path: '/', icon: Home, label: 'Dashboard' },
  { path: '/classes', icon: BookOpen, label: 'Quizzes' },
  { path: '/pyqs', icon: FileText, label: 'PYQs' },
  { path: '/notes', icon: StickyNote, label: 'Notes' },
  { path: '/profile', icon: User, label: 'Profile' },
];

export default function Sidebar() {
  const location = useLocation();
  const { user, isAdmin, logout } = useAuth();

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-6 border-b border-surface-200">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary-500 flex items-center justify-center shadow-lg shadow-primary-500/25">
            <span className="text-white font-bold text-lg">E</span>
          </div>
          <div>
            <h1 className="font-bold text-xl text-surface-900 leading-tight">ExamPrep</h1>
            <p className="text-xs text-surface-500">Study Smarter</p>
          </div>
        </Link>
      </div>

      {/* Nav Links */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || 
            (item.path !== '/' && location.pathname.startsWith(item.path));
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                isActive
                  ? 'bg-primary-50 text-primary-700 font-semibold'
                  : 'text-surface-600 hover:bg-surface-100'
              }`}
            >
              <item.icon size={20} strokeWidth={isActive ? 2.5 : 2} />
              <span>{item.label}</span>
            </Link>
          );
        })}

        {isAdmin && (
          <Link
            to="/admin"
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all mt-4 ${
              location.pathname.startsWith('/admin')
                ? 'bg-amber-50 text-amber-700 font-semibold'
                : 'text-surface-600 hover:bg-surface-100'
            }`}
          >
            <Shield size={20} />
            <span>Admin Panel</span>
          </Link>
        )}
      </nav>

      {/* User Section */}
      <div className="p-4 border-t border-surface-200">
        {user ? (
          <div className="space-y-3">
            <div className="flex items-center gap-3 px-2">
              <div className="w-9 h-9 rounded-full bg-primary-100 flex items-center justify-center">
                <span className="text-primary-700 font-semibold text-sm">
                  {(user.full_name || user.email)[0].toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-surface-900 truncate">
                  {user.full_name || user.email}
                </p>
                <p className="text-xs text-surface-500 capitalize">{user.role}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut size={16} />
              Sign Out
            </button>
          </div>
        ) : (
          <Link
            to="/profile"
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-surface-600 hover:bg-surface-100 transition-all"
          >
            <User size={20} />
            <span>Sign In</span>
          </Link>
        )}
      </div>
    </div>
  );
}
