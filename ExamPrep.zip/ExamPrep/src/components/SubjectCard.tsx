import { Link } from 'react-router-dom';
import { BookOpen, ArrowRight } from 'lucide-react';
import type { Subject } from '../types';

interface SubjectCardProps {
  subject: Subject;
  classId: string;
}

export default function SubjectCard({ subject, classId }: SubjectCardProps) {
  return (
    <Link
      to={`/topics/${subject.id}`}
      className="group block bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg hover:border-primary-200 transition-all duration-300"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center group-hover:bg-indigo-500 transition-colors">
          <BookOpen size={24} className="text-indigo-600 group-hover:text-white" />
        </div>
        <ArrowRight size={20} className="text-surface-300 group-hover:text-indigo-500 group-hover:translate-x-1 transition-all" />
      </div>
      <h3 className="font-bold text-lg text-surface-900 mb-1">{subject.name}</h3>
      {subject.description && (
        <p className="text-sm text-surface-500 line-clamp-2">{subject.description}</p>
      )}
    </Link>
  );
}
