import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  path?: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export default function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <nav className="flex items-center gap-2 text-sm text-surface-500 mb-6 overflow-x-auto no-scrollbar">
      <Link to="/" className="flex items-center gap-1 hover:text-primary-600 transition-colors flex-shrink-0">
        <Home size={14} />
        <span className="hidden sm:inline">Home</span>
      </Link>
      {items.map((item, i) => (
        <div key={i} className="flex items-center gap-2 flex-shrink-0">
          <ChevronRight size={14} className="text-surface-300" />
          {item.path ? (
            <Link to={item.path} className="hover:text-primary-600 transition-colors whitespace-nowrap">
              {item.label}
            </Link>
          ) : (
            <span className="text-surface-900 font-medium whitespace-nowrap">{item.label}</span>
          )}
        </div>
      ))}
    </nav>
  );
}
