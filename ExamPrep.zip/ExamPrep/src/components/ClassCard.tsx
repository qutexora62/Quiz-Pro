import { Link } from 'react-router-dom';
import { GraduationCap, ArrowRight } from 'lucide-react';
import type { Class } from '../types';

interface ClassCardProps {
  cls: Class;
}

export default function ClassCard({ cls }: ClassCardProps) {
  return (
    <Link
      to={`/subjects/${cls.id}`}
      className="group block bg-white rounded-2xl border border-surface-200 p-6 hover:shadow-lg hover:border-primary-200 transition-all duration-300"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center group-hover:bg-primary-500 transition-colors">
          <GraduationCap size={24} className="text-primary-600 group-hover:text-white" />
        </div>
        <ArrowRight size={20} className="text-surface-300 group-hover:text-primary-500 group-hover:translate-x-1 transition-all" />
      </div>
      <h3 className="font-bold text-lg text-surface-900 mb-1">{cls.name}</h3>
      {cls.description && (
        <p className="text-sm text-surface-500 line-clamp-2">{cls.description}</p>
      )}
    </Link>
  );
}
