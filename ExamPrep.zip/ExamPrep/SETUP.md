# ExamPrep Setup Guide

## 1. Create Supabase Project

1. Go to [https://supabase.com](https://supabase.com) and create a new project.
2. Note your **Project URL** and **anon/public API key** from Project Settings → API.

## 2. Run Database Schema

In the Supabase SQL Editor, run the following SQL:

```sql
-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Classes
create table classes (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  description text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Subjects
create table subjects (
  id uuid default uuid_generate_v4() primary key,
  class_id uuid references classes(id) on delete cascade not null,
  name text not null,
  description text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Topics
create table topics (
  id uuid default uuid_generate_v4() primary key,
  subject_id uuid references subjects(id) on delete cascade not null,
  name text not null,
  description text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Quizzes
create table quizzes (
  id uuid default uuid_generate_v4() primary key,
  topic_id uuid references topics(id) on delete cascade not null,
  title text not null,
  description text,
  time_limit_minutes integer,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Questions
create table questions (
  id uuid default uuid_generate_v4() primary key,
  quiz_id uuid references quizzes(id) on delete cascade not null,
  question_text text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct_option text not null check (correct_option in ('a','b','c','d')),
  explanation text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- PYQs
create table pyqs (
  id uuid default uuid_generate_v4() primary key,
  subject_id uuid references subjects(id) on delete cascade not null,
  title text not null,
  year integer not null,
  file_path text not null,
  download_count integer default 0 not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Notes
create table notes (
  id uuid default uuid_generate_v4() primary key,
  topic_id uuid references topics(id) on delete cascade not null,
  title text not null,
  file_path text not null,
  download_count integer default 0 not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Profiles
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  full_name text,
  role text default 'student' not null check (role in ('student', 'admin')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Quiz Attempts
create table quiz_attempts (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references profiles(id) on delete cascade not null,
  quiz_id uuid references quizzes(id) on delete cascade not null,
  score integer not null,
  total_questions integer not null,
  answers jsonb not null default '{}'::jsonb,
  completed_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Row Level Security
alter table classes enable row level security;
alter table subjects enable row level security;
alter table topics enable row level security;
alter table quizzes enable row level security;
alter table questions enable row level security;
alter table pyqs enable row level security;
alter table notes enable row level security;
alter table profiles enable row level security;
alter table quiz_attempts enable row level security;

-- Public read policies
create policy "Public classes are viewable by everyone" on classes for select using (true);
create policy "Public subjects are viewable by everyone" on subjects for select using (true);
create policy "Public topics are viewable by everyone" on topics for select using (true);
create policy "Public quizzes are viewable by everyone" on quizzes for select using (true);
create policy "Public questions are viewable by everyone" on questions for select using (true);
create policy "Public pyqs are viewable by everyone" on pyqs for select using (true);
create policy "Public notes are viewable by everyone" on notes for select using (true);

-- Admin write policies
create policy "Only admins can insert classes" on classes for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update classes" on classes for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete classes" on classes for delete using ((select role from profiles where id = auth.uid()) = 'admin');

create policy "Only admins can insert subjects" on subjects for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update subjects" on subjects for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete subjects" on subjects for delete using ((select role from profiles where id = auth.uid()) = 'admin');

create policy "Only admins can insert topics" on topics for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update topics" on topics for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete topics" on topics for delete using ((select role from profiles where id = auth.uid()) = 'admin');

create policy "Only admins can insert quizzes" on quizzes for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update quizzes" on quizzes for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete quizzes" on quizzes for delete using ((select role from profiles where id = auth.uid()) = 'admin');

create policy "Only admins can insert questions" on questions for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update questions" on questions for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete questions" on questions for delete using ((select role from profiles where id = auth.uid()) = 'admin');

create policy "Only admins can insert pyqs" on pyqs for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update pyqs" on pyqs for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete pyqs" on pyqs for delete using ((select role from profiles where id = auth.uid()) = 'admin');

create policy "Only admins can insert notes" on notes for insert with check ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can update notes" on notes for update using ((select role from profiles where id = auth.uid()) = 'admin');
create policy "Only admins can delete notes" on notes for delete using ((select role from profiles where id = auth.uid()) = 'admin');

-- Profile policies
create policy "Users can view own profile" on profiles for select using (auth.uid() = id or (select role from profiles where id = auth.uid()) = 'admin');
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);
create policy "Users can insert own profile" on profiles for insert with check (auth.uid() = id);

-- Quiz attempts policies
create policy "Users can view own attempts" on quiz_attempts for select using (auth.uid() = user_id or (select role from profiles where id = auth.uid()) = 'admin');
create policy "Users can insert own attempts" on quiz_attempts for insert with check (auth.uid() = user_id);

-- Function to increment download count
create or replace function increment_download(table_name text, row_id text)
returns void as $$
begin
  if table_name = 'pyqs' then
    update pyqs set download_count = download_count + 1 where file_path = row_id;
  elsif table_name = 'notes' then
    update notes set download_count = download_count + 1 where file_path = row_id;
  end if;
end;
$$ language plpgsql security definer;
```

## 3. Create Storage Buckets

1. Go to Storage in Supabase dashboard.
2. Create two **private** buckets: `pyqs` and `notes`.
3. For each bucket, set RLS policies:
   - `SELECT`: `auth.role() = 'authenticated'`
   - `INSERT/DELETE`: `(select role from profiles where id = auth.uid()) = 'admin'`

## 4. Enable Auth

1. Go to Authentication → Providers.
2. Enable **Email** provider.
3. Optionally enable **Magic Link** (disable "Confirm email" if you want magic links).

## 5. Environment Variables

1. Copy `.env.example` to `.env.local`:
   ```bash
   cp .env.example .env.local
   ```
2. Paste your Supabase Project URL and anon key into `.env.local`:
   ```
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key
   ```

## 6. Promote First User to Admin

After signing up your first account, run this in SQL Editor:

```sql
update profiles set role = 'admin' where email = 'your-email@example.com';
```

## 7. Deploy to Vercel

1. Push code to GitHub.
2. Import project in [Vercel](https://vercel.com).
3. Add environment variables in Project Settings:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Deploy.

## 8. PWA Icons

Replace placeholder icons in `public/icons/` with real PNGs:
- `icon-192x192.png`
- `icon-512x512.png`
- `icon-maskable.png` (with padding for maskable shape)

## 9. Run Locally

```bash
npm install
npm run dev
```

Build for production:
```bash
npm run build
```
